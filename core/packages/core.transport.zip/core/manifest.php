<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '879fb3f49e18c3969ec57c497c2ee7f1',
      'native_key' => 'core',
      'filename' => 'modNamespace/22075a63a229ddfcd654a03e90442731.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '6e7708490760aefc60503b76b116b9e8',
      'native_key' => 1,
      'filename' => 'modWorkspace/e1a64bf10ac0da9c00464e251387dd12.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'bb90cdb92348397a6d9d045b9e3991b3',
      'native_key' => 1,
      'filename' => 'modTransportProvider/a01fbe9a4428a677cf14b78231b52e3b.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '34775888c1c25050f31a1b08a090b38d',
      'native_key' => 'topnav',
      'filename' => 'modMenu/01a3da8b1cdcccbc6acff18971b0f2b5.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '087f5bc6c28f05ace0fb337f5f4d467d',
      'native_key' => 'usernav',
      'filename' => 'modMenu/057162946267b68bdd47045475f8e412.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '15a6a33dc5cc85946546ca9b7a67bf5d',
      'native_key' => 1,
      'filename' => 'modContentType/d83cdec26b5d9dcaa8921198153038e4.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '5cd5e453a7e7babb472fa0b3e046be85',
      'native_key' => 2,
      'filename' => 'modContentType/72f3cca5b445938192478b44dbee364c.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'f13285f936e9436923589472c459ec64',
      'native_key' => 3,
      'filename' => 'modContentType/5212c1a11a5bbabd9f763fba2e96b443.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '26617a6ec9f9e41340af27eee6377562',
      'native_key' => 4,
      'filename' => 'modContentType/000f625787e6e0529c7a6861b38fe713.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '624c3964c23ec0ad8686bfc8ac0ab440',
      'native_key' => 5,
      'filename' => 'modContentType/076fdbae520d8e7535f8dfaca7ddb308.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ee214ff46147bb1de7632838d0f69c21',
      'native_key' => 6,
      'filename' => 'modContentType/26e44f95baadd75352c75c2c5fc5d334.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '9e273fb6eaa898e4a0f497ccd9260c13',
      'native_key' => 7,
      'filename' => 'modContentType/2a35d8b44f1e70636ad63bf9b72be189.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b6c8c9afac4ece989fc3fd09ee21b7e6',
      'native_key' => 8,
      'filename' => 'modContentType/c234644a576efbc81345fc4ab5ec97f9.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a98462cf66176f07d16309d620cf3294',
      'native_key' => NULL,
      'filename' => 'modClassMap/c3b3f208ba4b613f40df484385840e88.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'cbe1d36215358776417637105f2b6b99',
      'native_key' => NULL,
      'filename' => 'modClassMap/be52da956d4d864435477e99288152c2.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7033248c4e54b4075296304505819ba5',
      'native_key' => NULL,
      'filename' => 'modClassMap/db1b2a58dc43e5a235e04d413825f52a.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c6ea2c85239bd0ae2e6937b6b2339345',
      'native_key' => NULL,
      'filename' => 'modClassMap/5e6930f144e92e50ae6e03998f8f2f4c.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '8b6ae86b5f3832a35e73a0cc6c214bf3',
      'native_key' => NULL,
      'filename' => 'modClassMap/b2db86bca7f8da024c405379716fe899.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c2afee4c61ffb2ef54512e57e1cacf7c',
      'native_key' => NULL,
      'filename' => 'modClassMap/ec75fe0504b02fe55d777ad84a230b34.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fef0d2bf4f59767e903d5ee3c63ea9fe',
      'native_key' => NULL,
      'filename' => 'modClassMap/43f27fbfc067213fb1ee4fd81b6097d6.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '23777df32e0e68ccd31e4059087ec5ca',
      'native_key' => NULL,
      'filename' => 'modClassMap/59c1ed6e2e111c1c2a6b5b17db4ee82e.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'c5a9bbc812c307c2b79fec5a64ff023f',
      'native_key' => NULL,
      'filename' => 'modClassMap/4ee571086f34c96b8f169495161ce740.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4de94caeac8ebeda2e12dc34fef9c486',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/cb7d40aa2f35652ea06bf1f72a2e81ec.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c83cc91edf34917a7f6eb92f7822114',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/d7fea66a9bdca6e7dd2ebbd6e4a37cbe.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff9f9a9be8ae5c550eeda1322afee477',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/d138f5c6ef41a3e0be3f861f62ddc1d7.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8852eef3d9977c715ec84c9b4865e9e9',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/00a2b5c8b0fa5aa158f5bd4b6493a679.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef9ba61962920b79bc3aff49ac37eebe',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/10cc0e7382a5cdd1f42f2f6664da0c87.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07352bc732e2ea8ca6854198e743adb4',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/3b89b7f69f956844685ac63593fd3c4a.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '83566b2833d5cbffc8007ebad6211c39',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/bd8d25e9fdc63a5ca3c53a5a70dbc5f6.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9eb1ca87fa883b084e0a930e8bbfb80e',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/503e97a8771f3dd627cb041414c275b8.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'da5d10fd8879d9eb2ba1aff4a589bbbc',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/42e3dea1620bebb0fff480223741293b.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7063ae7add36a5a0e99359b831dc783e',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/998b95b20b9aa2538587692b4a0ad451.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30c565d218c45cca6bdc2e82b08933c1',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/f44d7432adf52d411c4bdffbd9890627.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '80a8de85520778a5a05e0878e96372bc',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/90663e33bcc8adf67771a9901653d787.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dceb6e0377637e63951d1f65bde0a90c',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/942eba4d71c3332c2ece6c2f7fbe13e3.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a26967038dd13bdf78d6fbdc3895e0f',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/52187ee4dedbe2fb5834f378a3247e99.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '844f67dd926ecd64ba308f51346da3e3',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/7d813457a45d24b08d3debe51628e38e.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1350360fff1c24d995b0dda8ef27920f',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/5e4802f4e8fe7eb791d8abbc2457b9a4.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a67142d6d8c73f1bef3330262717110',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/54d90d8df3fbe6027200fa98e231b6e5.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6ecb32de30a2307a818e66e7285f20c',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/99589bdb6e3d67df54bae9f370dba2ef.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b31be35ff75833977f18fabbae45bdef',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/71f43e5baf467bd68ad411052815b3fd.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3110ff110f72b8328a61fe882097fb8e',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/d6bee5567b66646383c03d59e8125074.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '02f330c429359afeb79dfd0b8d6c8555',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/050002395c854c841d3fb0fdc5cc26ec.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce473b9b64b84b928704da85070746a7',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/1d157d97165bba379ec9fbaf229a8783.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '215d698af7449996f43bd900d1cfae89',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/65a029c2a8a8b8a4e58441f0e64fc337.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b05f314b806bc5188754433538027f9',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/1131f53069a6caa05c2b9387bb0eece5.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f31b4a530171141a62b688caa16dbb30',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/b3215e4579549ead8043d1f50c8475ec.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f862921feedcc659b63bc470c20fe376',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/b27d8d124279ad884d2a402bfe8ac7db.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68a68e08ed48134cd8fd38a9a6d2414a',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/1853586a894770d111d8725094cc707f.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca495c1e4c4566a27a51f3be06b2a4cc',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/9b24202fa60ab77ddb180af15d6dc47d.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34fc9aeddc3700d98d4a6882c5855db9',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/630584166e89d98e66f56643ba8e0486.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8a2bbe030d0f12b4e62fe1e124f782d',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/0232d1ec64cef122a8095f01930a3932.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42cbe9d705ac3699f18cc5a675b7272e',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/31a20c911568b670c9d74a1ec4f9e450.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b38808b728c8b0f97a909d078e417f0',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/83c1e84d431ed45bc9ac5944feafda64.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b0a1165d26b961413dd0753d5a900d65',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/09122dbae2c38e6618d3f3b973ba1de9.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a64211623b32fe114f8d8e86cab3eec',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/49f7b3f52a8b3371a6805d4705d1aa78.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81941e0ddd6790cd4f88b3d5fe6cb66e',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/306cb429c17e656f7d27cd600f70aeba.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee6a379f8ed628b3336a008554076886',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/3dbb28d4ab509f8629e2d95e27b0e214.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6ff3fd38af6c999928f66bfc15a72b1',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/35fa0988a8ef30b70f1ad7191d2fe6fd.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c11d440cb3957e08577605f2628161ba',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/c19314683a8c855067abf5aef2c8cc8c.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e1bc629084a70cfe5d5edbde01deeae',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/7755e4d23b08f9c0da41acbb26fe874c.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1fa882d0e8e440c5c101d9db5bd7af7',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/78e42174be65fcc0de7767bc95738b97.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c02c4b1bdb8342c0f938a9259d5e2ce',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/c3aad1cdbdf712a18cc86db9760c214e.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa281ac55f265252cb64080a9bccc498',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/122c8fe8da4f397f30975c3b8ea550f4.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b114293e4ee5146212c63954372370e2',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/0338589a000c27f6bb0d1a0e12980441.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b2f08401a73f42696500df51b90211a',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/f20ba1018d7ec4a997209e5462c29803.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a4d8f02c2446d3b245f1d04948096201',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/583bd44f3f858ca3ea9f478fac2966f1.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c46383bb390bf55b5a869eec2c133bd3',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/233862529d77e9553010672c5b7f3443.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be49207b7aa95f3e6e0f0d0d39875a78',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/a61f93d92d8b828e3f97913f9a2e3a59.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ed596fdbaeb97fb19387dc0caac7031',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/70c76b76cc8c6c527537e9d0eb1b1698.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '399a9be55a3dc1f868f01cc0aaca7f51',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/192e8130470c7f3332e0b2b6cb1b5172.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2e77a6be6d94fd8060f26eaa48f00ff',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/1dae9e16c32dbecee938938ce33daef6.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9feab55ca538dff6a4e5a00d503a21b',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'modEvent/144ccb86501a90c14ff197c5bb39fee5.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd60c4026f2017deff478a9fe67c14ffd',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'modEvent/b556004f14c3e3729233952641553ae0.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afaedb1ddeea1b392b3d6084e320d9a2',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'modEvent/4d5b81e939483349e821fc9b56c8c6d0.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f9affaf9cfd3911dfd047ca3119ed682',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'modEvent/7cffcc98f5c6f54af8a03f58fa3a8f1b.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '906e627b876cfa83bcaa0fcf07e9e677',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/9a9e21c1b0a7771c902837afc65cb74f.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd14447ff362433f5aa7ea7b1b14ac9eb',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/caccf879335c879bd749aa21bf4c8682.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4cd3650b61abcdb7a6397d56d60409c',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/94b7f12bc598018b93cb48a0a9ffb03f.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '23bd6f9826186b2990d1d955ea8151a3',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/f1e10909a6a56c17f6b84d0149055b2c.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ef8708229ad74683dbf5b25e51a2410f',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/eec5ccf8a5d3b52a1782070791ff5d0e.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe69724a7b07b7df168be22d3edcb959',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/a43d23f260773c54b66b2d52d894a6eb.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f67bdfb8d6302029285f76baec378ea1',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/8aa98b71e9375898f4fddde12d0037e2.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '004d17e9ef38925a4f5086476b352c4e',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/8e44132b26462ed05465a191aab0b273.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bd7549d4b2c4e14fd6e2ccd4169be32',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/de1159fe4ba4e231c679843cf7b813b6.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2f344a0aa549f46fba48d4243422e29a',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/0bad94cf77c443c7a1bd4a3ecad66234.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'adb0b3558489384fcf112ceef6eca1ff',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/ebe5ec03662a727fa320bb8d0d31d1fe.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f1122efc8ce98c03fecf0940c760d147',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/5142819e95e0fb1b7e726f03375b68cc.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05d177d041d6877d73297b5476daafdb',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/3b3bc314cba78cadd9c621a0d2ad9daf.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79893308b756ca1da4de74f6d1679272',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/d4773a046d9c4a967d962a1b5d7d27fc.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9f1578a22d9b6063f59a341316abe1aa',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/ddfda6ce90f2f2e0e82f3f953ccde5da.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f178bc8b5f7f9dfcd3d06b5055aaad0',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/ad12cb51a727e4fa20fc44ce75a29f22.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb97dfcc44b5115bc54d773ec84a8859',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/f4f90d8e0b25282cfcf06b643eec1e15.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8e3fceab72120ebc3e1781cf18bbbb67',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/96db413864c5ef72db5a9061c2583ea6.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e925e53beb81623d5c5fe5041313236a',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/f0772eeb8514fd7c5d927288dcd184db.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af6cc173ca8dc8ad90c5c0adc7088075',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/8a9d541686165c64d4aed8722a82a968.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ea7ef4ec2d4821362eaf865d7dd1366',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/aa76c1d2027ee1831efaab8e84e636bf.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e458239f85517852da20defdf5407929',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'modEvent/155eef4f7783c47b238ab043dff16747.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47dc921e2006c7e00c37a45beb7f9862',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/2d8bed4e1756aef0ac8a0d633120c125.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca17ae03f298d043aa045cd2223bcdf3',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/119136053a2c50d4fad8a8fb30ce46dd.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76730ff96dfae4ccf3a057266ae82e3b',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/6b886c236fecd8bb77f41fdc22416e15.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '92e6c5eaed5f1c89dba974e419f77d48',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/6f380e1a1cd92a1fc37c013b55637f1f.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2a5a5cfb20cce7fe16310617ba9fb42',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/8e345588797e3cd74b2cc925d5ebe52f.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eda046d5348dc1911012342d0bb1ecbd',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/2bbe4fe1bc08bcc573b48f77d14b3198.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e531cc7d247014d9843d63fbeee35cc',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/7352fe140a18ed0eac619b2c5daabde8.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4972a959428560f37bf971efed31fc09',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/89146ae436008d21597635d6664ce1c9.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a097399d1e34151037c9b68ac3601a40',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/e175370ca46dee494489d0fba1c73afd.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dee832b92d83aabfff36d1d18336b88b',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/fbd754a6d19f2c4ea382adae9641bd34.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e10ea4559f904ec037c207ae5f506c95',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/036b632563f6e942ed5c8e1d8afab63a.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9b71908db45373f6759d33b1ee806a8',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/ff48c5443da96a036e1dc93a3b927192.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'be1c37fe6fe106c7e61d8928ca95866b',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/d66778a628566db8fc08099a162caca3.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b98712ce73fb53026eea1ad115d2bc4e',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/a26b4ee84e7dc91fb8b5d9772a2fc218.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3f53d9dd882382e613b4ab859b98bee',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/1d0d0a16e0417ec918d1cd697cd1d5fc.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'df443165d0aaf92fab42f82cb68a60ef',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/4d133c1964f154eacd6bd023d48b93d3.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7754bfe89d88ee52b9e15a0b708200d2',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/5a2f6bb8212e34af3de48dbe9598764f.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '174841048c271b4025fed78e0817f856',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/84cb20d1bdb444b7a063b8ef088b1b9d.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99057eaa819077b4fd8f02dd76207c35',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/08dfc70e53a1eda07d9a6d64eeca678c.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b1832080efa485d7acae321685c17354',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/981bf2f175fabc3564a54b9d019dccff.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90252e2cf84c9ecaef430fa785b31dbd',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/990f1a2d60bdd859de3cef5fa7f5a8c1.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '03882c74de673260b9caf5e3902592f2',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/9ca64c9d2885c3083d9b1b926b8fe999.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2293bc01b194bc0e5fcdca3aaba161e9',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/e1d90a0b2114e4dcb04d8b9962f4c689.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e4c87f5804e015395fb3ad546a957c3',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/22c77c09174b9c37fe2fc3231d37b99b.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab142bccdafc927ab9b553c8d2059eeb',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/35394b0f434d8184f11053c666b3a8a0.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c86b48f43a61a9b6fe13d934e8f5dbf',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/d1311e64f109cae4c19358f6d410b8b4.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e1c7e0bc7f2b494cd8a04c4f272af2e',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/7a7b4339121d452dc6a0e35860a65e2b.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '799768f25ec1d1109d4e577ee1951eb7',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/22dc39dbc2e4f79282c37ce8f2ca6ccc.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b2b55a6310b28243f5ba4e120704e13c',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/3d7047522627a5dc6996f07228d4bc60.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd67f417947145c43befafa5c1bd47006',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/96f20d6bdd4daba5281f934c46eb1e5d.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1845a03bb3bb55a08b8f3d1fc9f846cb',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/1dc33f1525481f7eb184552cbce9d392.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5bbcb487e0170dcf7b9d9510e15a7da3',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/bde50d8dbc761959a3130cd91de5c061.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cbee869d03f4f270f706e95aee37bbab',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/207d810ad029a7f30b4d76ff30cc23b1.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a12d2e1faecdc2a3ffa130286f36066',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/a9a0a196cf4e1de55e648fd9b18ac021.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '34d5228dc7c83dd0d5bc52085bcebf7d',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/73b1dda55822976a9b9ec6232dfac274.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9eeffd2f9adae74949e99c0473a748de',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/fe4cc760dc7339bfa100117b479c670f.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a8af0d13ab480ec2245bda54ed9315a',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/08ba649f4dffdda3c9479aca5487d89a.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b5c670eb0b40bdf31adc9c9db7dcbd5',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/3b5d60251459a5c749150f23a258bec9.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '90793b890368624a02a6eb0d5347b7ee',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'modEvent/4cc69b541964ca64fe8cafb98ae593d6.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b778ece96486ee8d812d25519521b79e',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/30949ef2dcc3bf1bf08b20533926342f.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8ac22fa252d2e0a4ba366abab3f568e',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/5bd79a190abc1c72686a3d643010034e.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f950ce8b0ba2bf3570560fff7535de2',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/8b4db6e8b82719c0df04a22f62ad5c2e.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f4b04becb26f5271a40b2f57fe5fdd7',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/fa8240027e75bddc30175b34c57ef564.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2645eb0638d581f4a2540a1e734b99c8',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/903e2fc13a10441476bfb92863f3f980.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c275ec46281f4a680e5d435435340608',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/ae1525abec2c6b04def3f2766f2b1d4a.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8f0871bab24b12df73dc343da496d6a',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/67ef8f5f5e5ba792e2f8696fb2989a3d.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e98b34b86e728a97e110ca21c4f97f45',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/c83e6758114098101872176b5ee0e120.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bad493a35b47863ffea8f8196598234',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/641f91e1db6921955e98a5261d187e87.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '328682fe6fa570567846d81cee9e3b35',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/68b8c8339edaf8fd533d5de2dfa162ff.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '16b6a042947eeebd8dca5b874ec86eb8',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/b8871e5457402f9719a07acc0c2bab57.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6f8220b118bcb3623ee9f192d0fa69b7',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/ffc19dbc6ada24597c599a674c10ebac.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96e17aaf71aaea859960834ea5f99cd8',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/0d4e2715fe65a78125c4a61044f185ec.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae07b4d61c4f47fa127bf75381d20432',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/471a52df5ccceb6f3f24eb3d70d40ae6.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b0107cce05a8a286fba0474688533e7',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/79285e6b409a081f158d1654f30d2429.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f502349ca70ed601eaa3cb1d8f0f4591',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/76a7fa300a27a32f5b487ce96a7793d8.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '725ac89b6f1f84fdde7262a2184c1f13',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/bc285b0b56515cf29a4ca50db7909503.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43c470e62e61d7a9f7f1918c201880ef',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/826019277a802d255eab7d8ec56145b6.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '657e21b4d22a40202ab6085f40a5a7a9',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/2198ea2b5f475cf668c02fa6e14c7e9d.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9c4e0b16a3f3f6f7acafde3d8be1f0ef',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/a23bcb5efa38dd65a4adae5ff39eb684.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3a4d7da07975d8262adb2ce32f06496a',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/2457cf65ac73b8935828fb24d7eb59d5.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ac13eb9cbcb71e204d712ad80a7d3fd8',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/a37e4b74c491b6e3910ecf2aa49761a1.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '42f0f4ef76bf01c955b160d0e95fc75c',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/f9858ede28f3e372b38351d012b15fd8.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07abb2a5af6170b88c4b493880d9c6aa',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/33ab5e59d2f9d38509b15f739069356f.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4f389801c80620ec1550312d6eba7f36',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/564dfa60fbaba375ae67a31b3946458e.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0fcf575b2c27eb9599e532ca110e2b9',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/542ad530176cc798a0a4863947f4874b.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eeeb03e7731e366ffe40e4023105c4bd',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/1d369dd28b4ba457a342c5a0604aa3fd.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dc122e8d54cdbeca09016f64989161d8',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/462d48022519d0c4ca643b4b10171c32.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0bb6f7a594ac840af5344e7931cef50c',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/d2f3a41ff6cae8c8d5c86742cf732c82.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6862d62e6850e3ea4c52ba94459420ed',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/5f6672dd0118414fddcb298cb7bdb780.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '941b8b62ddc5736b475ac72623dc6214',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/3764c9a93be574c7902c571a84eda09a.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7a3cdb71913c632e93997cdc7edd33c',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/ac27207d3882d08b421ea495bef79fa5.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0f63728e1eb2ebcf391b65f6ca4dfe7',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/c51520bdbd538be3e095b6760a0f5356.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a111d846a689021e65d1e9a3d5d7e0d2',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/399d38eea5a02d4de2178f47d6f63cd3.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bd1c90ba4db05a2dd2b4db06223bf04',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/5f6b344ebd1ddf3a2704fdbb2b11cf96.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c28f7ff322c669204414ccf6b5b385d',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/f70e306b359bec9a75bcd72d75e9b36b.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd234a6e1e9e12f54015cc02e5abda6b',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/1f33bd3d5fea752a292523a823a1dadd.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2091c98d080d883021d02827024f444e',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/56466c45e44d70cd5c83866ca603d2b2.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a61bc27d4749496f3113845a9c90d25',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/7e75511ff74a3797e5ae966340e6d53b.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bca5f7d154047671f8be8cb74c311d91',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/4f8e1388be7bea7714465d0416106949.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a76cb745b17c6c0b315e840ca535c79a',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/0153d690850a0c99e444fd412922424a.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9e2255fcdfcb34ec1e17684f09e5ff0',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/a76b110617e047981ad08cba36d6787d.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31208555b6697b190052b770204ba17f',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/83c620569bced300f78ee96dfd90869c.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d7a49832ce5822d86be461602520cfb',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/f6e0930e107b3abe2639b078b4a7a9bb.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca4bba16f07cbc3804466b8a8b4cf311',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/1a48ee4df3a145cefc87b8385ba9d712.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f96fdd3fc8e4dffe8401abbb0b0338c7',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/f06da2f401d37c27be3733d01046d451.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '255a0148084e75e0d119b918cb647803',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/f0b593d55fcd6ab1654c1c073a4013d7.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '29c93f87f32afb4a1bed00f64e239a5b',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/04cf1e565d7131c2e2380d7e925136a7.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30ad99f150d222d5ce6c0a75d1ed600b',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/388a0d43066b8656525aa1a5d980d3b7.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96209225e6ed85fdb49aff49146911db',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/11d263701b08395970d486c6a921f339.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2028cff6431ca86d6879febf694f75e0',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/53845b4dcee0373d53fc6924d9e10a6c.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d67fbc25e1044d4353597bfc8395010',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/8b46537934d2cb547492d8b6ebf67fad.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d29302cb6341b83f034b45d520bc8a8',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/7fff33097536129a2e1d73f708ddde08.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ae672ad88d3ca5d94d3d3584f314839f',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/4fe7bd55af5ff0e6350977b539c5e15e.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '065484711630ea651ced554f6cb2c81d',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/d0cd8b843d2e1bcd6b0421c624c3bb25.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '26511777bfcdcf260bb03f4cbc6f3409',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/059a809df52ecaa6f46af150069d88f0.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '13f0398282e8c14c0cc5f6fab81baa3d',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/934152c97754d5c987e5d5bd0f615e1a.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f70dfb4df11038970813158142c2420e',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/a19de5afb6f8e91af2e2bff5afde85ad.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '304ce0fd125e4bc7fcfe7d2730719351',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/f2dd54036904fee650ec7210b77314fe.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a5de71d1b30fd4b8d16e18e34e05c4ea',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/6b48963292df72e8c31eb11e77041876.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2cc34f97dc2e9cc06953fe07dc0920d',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/6f647913da2f3f9943ff437a79fc67a2.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3d36b6a33fa776bfdc676381a183f30',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/51b3e3208a31c90c1b87bd761bb99ec1.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e93788fa959cd706d90cb360469d887c',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/9d437514f87644e7aa8147bdfb17bf24.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6796882798faf288c6a8addf8f9e01c0',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/5c3ee14766677a11a77083e505709bd7.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f7bb3eac34652e793d953ac0052dcc38',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/dfa795e24bdd1435122879a0823b1c36.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '61d24309acd17ae37840cc106a0a4f31',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/6d13c65e5573bbe28c60daf94088aff8.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '967460e57fe3744b264e9539b76fa3e8',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/e2200c2a93ae56c58988005171ec2992.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e257f22bade55772f63ca510e7ab3aa6',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/144c024f931b9bdba4e15cb6835a4120.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad86fb0853ed6e84821f3bba95a31e2c',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/53d5853fa2e678adb37bd79298ed5f60.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd6d10ff05dec59d429b86ebfb8b70a9',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/337a4fed0e2e92a3ee451c92b7da3797.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7abbe79cb16d0ad2013be059dda355a6',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/d21454f0d9b6207fd7a48f07533a7124.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d0c4daf8253a7544329be143b02ee32',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/d288aa3618b9f017e4214f916e3828f5.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3bd1e020474cead0b576c4985a3da18e',
      'native_key' => 'OnPackageInstall',
      'filename' => 'modEvent/0ae246517afb414d2bc982a37a3dffef.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eb8ab17bc92f2508ba0184e178c4fdf4',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'modEvent/49fdae7acebea01582d81aefddb20295.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f2f3304d9f9b268871befc9f210ba1a0',
      'native_key' => 'OnPackageRemove',
      'filename' => 'modEvent/82fad52b2c9e1e10c86030555021cd0b.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e376e6eba00fd1ce8b5b965c6012efd3',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/e633f6c76ca867962747b07bb44defcf.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db7a0dc0be154ce3e375a38e014e58cb',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/ff2e6918bc061de6167fd2c0984fe5cd.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da3fd6349f024521a00eaf1568d3d678',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/429046bc574a284f894b63e2bcd84939.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95743ff2e8ffc7f39837c14358f6569a',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/8fc95d6a488a231b27fa6c24cea6c381.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d0b8463748137775d82f9034e1d344a',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/2838a628d8a8262f9cd8eae7d5d6b3ef.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cd68e8405b17162660ca944b153790f',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/7db724ba912c16fb3c41c72210e2d0c6.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cdda3f43c530ece20c085c01d563293a',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/c28e1884a4adf26be70150e949393f53.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1e73dd201a7b698051db7ad50e3a645',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/6dee131fbb12f558bbd82e7d82152010.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '653f06c8c8ea601083318a94165b41ea',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/94912cf37cd9d99b171c761fa51f0178.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9938c89f497efdc8012428c852b6ca68',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/49febb7531e8ca71235f212c4466c530.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9a1a2864433ffb8f093dd7d41d055c0',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/cbef59cca406d1521ab1ac922900a734.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cfdff767e98e15d68d8c0d5f688c766',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/adfa77af772fce4e3f55510b88446707.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26945d45ca8e126fb78e146f98558103',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'modSystemSetting/1f0446e59361eec781b20bbc507fbdb5.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'faf32bbd816ad70a1ed15c678242e0fa',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/fbcd9b315529f5abade52fee54402d28.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6be9d091c8dbf960d4e428ccc85acbc',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/59ee3e4581c8c0125afc7b7b7ae43133.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c601b0a7262a03bc5833197dac93f52d',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/64bc7b45c33101cc7920a0dc8cf6edd3.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7969c3716bd218025a91b3ec3424a01d',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/4b9c46e16f254d6316a8e1a68e0723b3.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23dd7808ee536279b02426aed26b1591',
      'native_key' => 'use_context_resource_table',
      'filename' => 'modSystemSetting/b2cb091069a49babaa70e1bcafa7210b.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92533fc4760b8c430e952a9daefca8c0',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/71cb15aa480d0f6173da1e6e540bc722.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f4fb7879eea0e7c4714d29ff30b956b1',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/b74d8ccb6d0202fadf9248f45736264e.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '718d1eac20a6c67e953391ef3526cee1',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/e04da4c73b639d78bc2bffa5d3764242.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '468b5d9420ef0900936398cdae1e69ec',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/bbbc57d29a19253063221b4bcaf55262.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '634abb7deafa0fd2745a069cff26b332',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/6042c358ecdbe51a28959aea1ed5875e.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '388a534874b6a95e7fb99b4acd30e2a2',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/80b52220453fd45c5966ba855039b0e4.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fbd3b0c7df0376e44a522a5a07a2d712',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/e79866058e47cbc0c97810a3ff9060c2.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59690a526b315cc2d2aaa8984d0cc72d',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/a1b7d82c905ff7dab516167b489b6e7a.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '384fa1e90cc30dc1fc87399a254e02b9',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/875a2b0b3b5f0303dc958ad92f2350d7.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2339561a8f3b1422f3481c8df154e217',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d9a19c643d19aaf723765bc426c2f9d2.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '01e3632dc458fded5c0412431c6c6b9a',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/432b52bdf7d29cf4bad9ffb4e7f5731b.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93c68a9d54825c1f2a61daa38c2cb618',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/76b4758150171b9ddcfc263e5577fe8a.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a615e669da86df4cebbd6f776c90336',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/8d447e684291262a13791a757ab87982.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ee3e7cdc6a55bf53a46bd27d2ffb5f0',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/57f2e3a833f6c3f863c591028516fe9f.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c4a585dfb73f59d30a4ca0f1ebeefeb6',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'modSystemSetting/90df1f3178e185a4f4da41505d527808.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '940c9314c5d40d96dc62b3e52f02a011',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/11a978570bedb56484f9957330bd4e64.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e05b3793315f6123c5cc0ca8ea81271',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/7134eb7eb3399566f3d64fe0b34ef6b7.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6d8a1b11430e27156879b51a211a0517',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/9b4910321cfd8fe8270c7c97ee51b1ba.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1721d500cfb8aac07a7697e292eb90e7',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/0dfce50f582c044bb7a7dc19d91edaea.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d0cf3468df53ae34040b48432e6ddcd',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/40c0808381e190522d9904c65790e278.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74ced9e8764302f91498b9d5f8668595',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/dfedd4e9f85861f5c752ab8136b43015.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f50f2cdd186eb29798927c70ae196204',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/79a7c2ee2354216e8b49efb20af4517c.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '073d611153e9cdc9e833b77a5d33841b',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/52a07c80016fcd3ae5f494ef90b5adb5.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '233282b10b60f91421e884e87875872f',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/8265bd7b91a57b721f17a7909c64fe9f.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eaf5ca6d1bcd1330219af8dc5f1b1ef',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/9db3443f3cfe131d5359b2435e0ccc97.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '123cb557a4ebf015665393b14735f74d',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/a60e49a540beea143de9c937f42e8dcd.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95e3c89db77dd473c64decdec3807fb8',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/1b20a03b301002f792f44ba8da1f8253.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '434bddcd1bed1e42a879d8e1dc948392',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/ae8020c02a6c91368288d3a287b4659d.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc200852c238154672c8ff34763bb591',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/f889200e55f9eb9106d72fe22edc9c7a.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ae7a7f72e59b7e2099cf20c478ba59f',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/32ffd44f6e1d051fed4366b156943ef2.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b86268fa910f39fbd4d4873cd42a8941',
      'native_key' => 'default_media_source_type',
      'filename' => 'modSystemSetting/be1bcd3d976650bf39029bc9cd92c412.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f14a9ec858380fafcb11eab93cc7a5da',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/9d6d683f298d4854508cfd7b04395bd8.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53aac974d93300fbc27b5677d43ab7fd',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/d662cdc32e38ceead00d74973c277b68.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2bcc5c623b81ae42ade8d6d98357842',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/cd0442672e6f98bbe052d65c5ba844a3.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2844b60543388a5b713f243d3b26cc3e',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/93303ee0d07742e055b13f80f7ac4b85.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f8ae720886c441b7a904fd59a7312d8',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/8229fdabf9d5ca6e51e1ec99f0129869.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '010083197c9521ba189af03417c03b57',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/21b0b24b72e476ec2b6fa45f51c46623.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9b58f316a5fff4e7928c046e111f2c0',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/0d8aac2d244a30712892be32b03bb398.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98864d6699421f6c241d947ad940e9b1',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/093616d1180fdc552a65b2e658cabfce.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb5d25e6d07e6172df4c79ef02b617e5',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/33d6d7b080150ea709faedd290e727be.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3880bda933d4003ec78ddc06938120db',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/8cf0c4d7d111aa6a39f33835884bb9e2.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd37d7c82be5f2bf18639711e3cc0788',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/e7dd1558a7060ef79446380a4e9be884.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0be87b667ee921155ae3f7dd7c406483',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/625dc3b75dac42f9c4c1008b4ee3d9bc.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4dab5b5dce8930e6e1c3cd2823331a95',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/1a3c85d4b4a19faaeb8fd541debc235e.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f2cb2bd7f084fbd2775f3816190875e',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/e43d0da56d85da5be7f1db83669b76ad.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f643f92a2cd950088c291d11162aa34',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/4f420239cb037852476b72dce521147c.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5fe8314245f26deda231acd1c02968bb',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/5703df2fe93b5ce231c2e1ddacc5fddb.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '435c8a3b3e96997222313c459fbc3e2a',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/d6fade87a49a7d9976637ad6ec55aade.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75e06ca690614696c7acde8808b5aa01',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/f1c854937f818ed2ae56a15df2a627f7.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f651e8422c72ddbb5455f86a0346e3c9',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/c5c31474193a95e3ed45e03560233a90.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2b564c529ec435efe6e80e4b2923dc9',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/32225656fcf615c8eb47a2af9bb6fe45.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1390bed27a68941f6bea7bf602f0800c',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/6025b0918e2002a1b092c730da24a5a6.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f872de86a2441814e557594b2ebcc0d9',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/347981ba1784491db706f2787d78be37.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '963064ddb60077a737d9ada0084ef0b4',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/f4a35edcf4c87074893fee7bb0674892.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a74b6bc264ed0cff9b684024f19385df',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/bd2da590d4280aeff8b1b4b1b2cb3033.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '849d6d27c85391268516eb6eced8e000',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/ab1eb66cb3106eaec5cad167f06279d3.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '552001c40213e5792972eba0c5ba701f',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/c723bf6cfacf9fc02610fd277044f76c.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4312d39d9413bce49c8a8a8bbb77e234',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/d3189f32b34e3cdddb195899ab2a3e15.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47e294282968606b6006ceb56d2ca399',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/cf00d2d8bd70a778c0a1b29b27b6e041.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a70caa737ede57ce112e277bfacde4c8',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/e5ae512cd233220071f6a17c31f6b198.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2cf00ebbe65998f98d3a4cf03e01926c',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/b5085096c52fb4c7f9cbb2cfc05d70dd.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b000c213d8b94fd711204efa95e9031c',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/a0f982f94c6fdca78a99950a9c944aae.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc6394d4584f9e8e0188ab1a23c96f1d',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/6382d8a9515833736cdab40b97ccdc18.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f76ac4cbd8b51f80ec6586ecd54e42fe',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/ae9fc3809ce52c7373b1191a470eef74.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '711b6f925bf3dced046b2cd40b0f61bb',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/c413a515ec437a26206185bd76c66c8e.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ff21617fda887ab5053968852147fd2',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/39265d54e760a8a78a50adfa1a81201a.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34ae8afb5f95e5f1faabe49ab8cebcdb',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/fb6fb18b9a54a93e28c5765b2cb30b6a.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d1f1bb1b37ec35c7e1624b9b2f90d57',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/a778551079c135c0264b5499498a22e5.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec90a33eec3486b05eeb95692aa85f14',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/930dcf171e93a947f6e04252fbee473d.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc714ee150a724925a48113382e8b76a',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/3b711498c8836971c278ebcd9e12604c.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4e3719f3a5c83120487d5edefea2f7d',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/988e1c721574e939256dee883d91d794.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc936efac61998f22f27188553505f8b',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/31d49940bbaddebb34e189c4b276eefb.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6c96b8c1daa962536ffab700a6db355',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/2f9f662ebe14d8fee8ea114af4360030.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9241f3bc63d85f3e4a88fa547eb900c3',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/2d4b72030b333adcdfae99054bd8db6b.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94bacc945a1260e570848dc45680ba17',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/9846eb61b8f1eced4ab29fe8648d1f31.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '181c56c359c99f058608088d1018455d',
      'native_key' => 'log_deprecated',
      'filename' => 'modSystemSetting/d0c7f06ef93fbf9f175cb54c3aa8c28d.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2553a4e4fb34669bd934261d8979fee',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/aaa6fe1cb558cff523fe2338aab4894a.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4657a36479cad909a9da249ae5781fb1',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/6fa938751e42e3bc161ed12de42c087f.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db6a88a8bf36b56cdf9011580542120a',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/3e9b3c812d8fb2027a4e816f885939af.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7dfa2ab9bd519f2c4ee03798c698f703',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/f293c3106ff639e463f6af0d5221fa56.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd448a1c4a9ab97f28e781e35902d7a7',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/221f38d62c85eefc5226f9c8b3813f9c.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe755d559d5e4cc5b80880a5cf95eaa0',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/e3ffabb789109eeee1317df152c464ff.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7591e74be0f010c20ffa417d3b907f9',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/352a7957878a9f0c7b5fdf807a316361.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5876ebda84859c8dca46cd4a346231d',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/25cbc2ca507dde918f32e9bd3e9f26b3.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16b9ab0f361be9c818e8c4711d814ad3',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/c2eb3a99e8852a865b9342b1346611ba.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeae4196513e1796a7828dfff5019887',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/cbc8cfb7f8a3e286477e0635250368af.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d42ec49ff56d3814a3a2ecdebac8db1',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/48a90fc829adf37f3b59efd6afdd82da.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33778f3014ef8ada7e28389d8fc2ff31',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/dc305e6fe0d574c16de18efb86693104.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21e51e8541f75850ed2f1a989d1fa066',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/98f893eeec229f5fd092441bdfdc08c3.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '430aea7e1404645ca4db19890ed4ed44',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/3396bccd783040e6859b24b7e876dc05.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d95fbbdc9c36a07dd80e9d15aee3c7f',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8eb7c168a6e490d4eb5815547045a844.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a54589b915fef773b20c86ebecec8dd6',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/cf01cdc40a93ecf1d0b281873cffa987.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a12d1fe57b88eb53eb87f38b15ddb3e',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/f7d3a8e828ad823620f16fc104adcf12.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0c959a088683424f21fbf37ce25ad9e',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/e796ab303f9c3c21d8282347e3acda8c.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc52e1b3900d06399b7e5d016f4bfe32',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/0491c69adeb3bd6ea03bec1a1d59c2e6.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6c0caf60341cbe32057521f3dce1ab76',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/27f69146445c8e5aecbd61cea8daf229.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f48bda3e625578c95bc314a05220ff5',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/b478907d7ddf4362c2100eca950f1593.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e727a1f2cc285245ab62c92b03a2d277',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/67c1014a3c8959cc00be46537e45d9fa.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '954b1b3ccc534bfc787cf1931fca0ed2',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/3b4b0d4cc13bd2326e3cbd26d4c02aac.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08dfc324876e7bd1db0c556733d1d3e6',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/05c40c44c593f206af7d4392dc4aa2ca.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5f959789515f5bc72568c9d1cf9ba834',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/1379720bece7c1c531764e91edf9c76c.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23e1969b1d77e68e0aed4acdf27d358d',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/93a0a86d43a902606a578db81eeee2d7.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f2028347ddbeea49739fc94f0e9a89fb',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/bb11386de79ebb88dced1b79cd076c81.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc92c2e912e5a1613032070c4129c896',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/3c4fb2e801c0451467df701f39e7cb39.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e74653f074e0f31a1384d090c8ce253',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/aa3b79cd5f5f866f9c0ad6ec7964d35c.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8e7c5c8cca2d6c667cd9c7b475da35b',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/03c84b8cb75553a3d54c98174521ec45.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a1ebd770284af5973cdcca6e337916e',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/a4fedf6162b11772bcf7e90836c70101.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd7ca096f53c94566d2f76f2f6688989',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/e3097c3451b470e14e128ee5bf61a011.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd99c08bdd7530e60593841792d420dec',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/04947a223e173a214af070f0b304ac81.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6a77b1fff56d9211ed714db6fbb80d37',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/17de7888ad367104e6c9a41380438b14.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '418f933c197f89d4df6efb9d09529589',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/7c77a7554564bc99b59fcce9a3b540d4.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '94617d8f5dbcabd7a1d835669ce0eb25',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/b8337f382b946ba47ac7d318bff2d011.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc615274b3ee00554e012820201396dd',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/52a7473e63fdf6b39642d74730c18503.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c91a3f9fce659b220157c75638bc22e4',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/db8ef759792da614c278c1b4edc51bf4.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '121a9e4b32cbc994710249b46cd2c996',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/e70669689be029fa161fa087b7846a6a.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a9ed7955dda030cfc23340a6b5d61ee',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/e3c743ba75ddd330a91993e6f2c76480.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f84a0bbb3d35f19c58ad9602fb27109f',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/1782ef87b776b7bbb5c854d77237045a.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e1f69c87ec4322ee25207284bd09486',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/271029f52d31ac4d6801ee1123eaa3ad.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2af50d6c08e2ac8f5443eaf7b14796e',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/2ccf470ad8a5cd542d9e55384b4b092a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eb106af16e41a8df653d92503554586',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/c8d924582c8cf28a8bb413772f2f40ba.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66b9ce505e02a0eaf56d549a1006de7a',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/8eb2ec7c278a2675c6ad594a92625ffe.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a68fc002cf62b050dd9602767121d865',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/79c916870e5276328a756b474f8049bc.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0e832f611bc6935ae28912001dc3309',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/441e2c7aa28e4f0f0ad8e8b9ae26eeb3.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7e05103ba3e3f2f5e7987ecd3baa3c3e',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/bff3b1b8a26a090d540f016d7ca5d20e.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbce0582ab6e551cf78df67f3a7b7e7d',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/ab64b20560ef8297efe090512df47bd0.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c76713bdc483d0ed33f673adc4e297e',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/a97cb0798f6351b2deab1428c494afee.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1d324d36a4ce642fb5954ec01751e70',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/b10565a3640051690b1507e58f5e9bce.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '723fe2ee86b5b0b9f2a2ee351da0cafa',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/157175d6a6b8308fe9292c9ebbbcb45d.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c93a7750fac5269ff2ddc824dbe6935',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/b3602e6f12f131fda46623f756f57598.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2971717a5af0a614683527bb84287a6',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/317c08f0ffebaa5e561d26734b019727.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e918dc7d18370e81406a72b8e9428672',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/2a15e574b6278cea3df2772cc502fcc1.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a9dbc4acf83e123392bf0f78874a36e',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/74054038d33605efd1c5d5f7b20df944.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '947a873cd2622c29db5e4a8980213abd',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/daa90f7d76ccd3acd42884785fb47812.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39ca399f39041772b4a76e31d3021581',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/b085e5ee719a605a4cd8a63c9e186780.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67a14ba46fc797815af0bc6097fae268',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/a185e5fe036ddea007f4e791c244598c.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e73c47f3e14a17bc3b7d679cc2a23e5',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/15bb1fce5938212c6084603915a272ed.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3289b21c4846b7e668d17ce3db357cd3',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/4318824f0524e5d6883d9aebf0ad4575.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc5a2497b39de18bf828516214b5c971',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/1f7ad0afb87915c65351be288e9e94d7.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd753562c9473fa0a8011853ded2f0d81',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/0214b9e7be8ca891431d047604f4b7a7.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37cc0c18335878e8f727a27874bb8ede',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/b432bbda01acc485018425a82f332c3f.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3aecc0d929217135d35dcaf99ac99f4',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/1c49176fda282e622267aeedd3c4fa8f.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '276b062a553eb93d2c1846436fd21c61',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/97456be05de4ec4e25a16ddc23768af4.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '225b91d96d0dc1ea89608265a868ef21',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/8b5feca286115dcd191e74e1f8a7c9f9.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74a76949cabb03e257b668e695fc5a00',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/d6827e2a772923584fc1cac06cd49e40.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3ff9722e81c5a3d2200870dddaa2f01b',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/b6a96351a90789eeb6dcaa74f182b039.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7937d3ce7a32b709a63d37aec030103c',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/ce250161d142b2c10a67669bc094bdb7.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '083e7e9adbfbc543e4ce4e85a726ac45',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/e72ab448eeae32d201b475448be8edd0.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a737eb5eb70a6ffc28f42f9d0e65f498',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/4c301cea9c83a61eaa0044bdbffd4b22.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66b3babee19052172ff17c9b34fc2ace',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/fce202dc4a985f7b4426764e916773b5.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09625735705ec8e6e742e056f820e8ab',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/6d01bed5b390d6bdb5650b9a166c6ccf.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '074d3c73f10f948e22e293711986bf98',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/c548d6d55998a37bdf148da5d67bb780.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67e785a45772442904140fb18c5fac8a',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/7945738446cc4946535025e31c398d71.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e133bcefdc55f0e83cccca5834ed0753',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/5bcad2809b2bae1189b1febb8b0a7e71.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2aec81af030c1a526b6dcf72e301906',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/0691cb5ce10dca115f0d9b08aff35361.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87f3570a930c9db999d0d23d776579e6',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/b16fdc25322c3ccf640da7b1713500c4.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bcb699266fb268ce5032fcd346522cb7',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/2a6b028eff5b8257f289583b35f3fb40.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a461848c3ddde757d06a6a03a4da876',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/696314ddd22448938db0d83042d8b66f.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f4b9913033903f5fcda88715b269473',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/537ec8d9379ea21fc01fb44fcdb184e4.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a5cb4e0d574875ca936c73572997a10',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/96de58fbdd637cb3a7242ef778ff9753.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bd6ca8f35ce91773df0a1971f122b38',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/771b704494c4bb8bc54682969bfdd5a1.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14157400712ee7f267b49e70e8217c4f',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/5e09e88bc9e98427bf7b91934cbe19cc.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eb60e48db8f764b1bb1baec278e6e4c',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/b5436d01fd5ae677385f43c7037f2c0f.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '00185eb30f794030caf0fc2db3b6f4c3',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/db4970f29006bac66ee5dfffb28b2196.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24adc63c3f43d8a75031a1db724727e5',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/5f128bbdd821a0b23d7c12a7aa52cfca.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b07e68b3ba39edc4700baf344a793751',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/85e867729f4ca54e1959962cd35b71ac.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ff154cb7aba8a01a793538b1dfe3833',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/8410e49db82e8f620172213043580eda.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4302091553cb0608d1045343618b9967',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/54403338005885ebcda5d06a6b3d58e3.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '485d6bdf645383b2b898ab94197bb689',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/ab356ea4ef6539683727a1a8355c4285.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88102fd8a31bf8a1f0cd1059d068caac',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/79c138d2eac5e7b268fd79d58450a47c.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b3184426ae28268c0704f9d85d012f5',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/54ed43f24e86201c7374b0da88c026cc.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b15c0a7ea80f5e2ba9709bb4bff72b0',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/838a7d4baf7a9b92b3e4cf987168aa8e.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f27eba782684612dc5bd046a5253d16f',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/941c09815afdb8037f82b4fceca54430.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bea79fb8f029920b5e59d2c5e89f7394',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/123de8b3840d1ca5a8fb7c16659dcd17.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82ac046fc48a22aee51b89fbdaffb942',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'modSystemSetting/8ec1324df2685f9256cda950c1d8c523.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51928a5ea2a27ca93d1a8d105ea4aa20',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'modSystemSetting/363c269f205e3f73358bddcf58e17432.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b97dd708db16430f1c7df0eba6402bf',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'modSystemSetting/78a265c307bf00c4b65bdaf9bb00d156.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '246bbafc5e12e38953c6cdca73bf7437',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'modSystemSetting/ae861fdc6e2785c30e7f0e9052a4ea77.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b92e5665000d3f33e213a2f135c8245',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'modSystemSetting/12af2feebef7ade851741563464e5cf4.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd056ebbbe271ba0f361813126b635e44',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'modSystemSetting/9ddd97bc74bc00851bb166e3747ef9b3.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '507409183f2ad381f3e25a2cb4e45d99',
      'native_key' => 'static_elements_default_category',
      'filename' => 'modSystemSetting/4875d92d794a3e5ba8c62624048bf23a.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '15f01ac03d96c0a229986e6b7b0a69fd',
      'native_key' => 'static_elements_basepath',
      'filename' => 'modSystemSetting/367e3e6b209b02309cc1faa9146246d5.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04a13fee82b7ac36a6b4dd000f3c122f',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/b99687bf3613fb8c3b2a45fe02953b5c.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a9cbba06359a80a50fcdc7435f5061e4',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/c5516457a87fe9ea1992e5e86b18735f.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09603191002c46c93731633f693184d1',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/e1d54094270e4993a1690adcd780aae0.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ca53f051d577b4a95799bc768d746e9',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/eb534328b8359d76d9001e4dec41595a.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8fde018bd91201973392820b285749e',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/740d244f34e339ad2d368983fa53efc9.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3adf474951ef64e919502297831a61f7',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/9f605402e9906bf3375d9d49804400d7.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f23c6ad9f0718be039fca5ccaa71aa1',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/4afad16e8c4ceac9b1698c5f8cf3de86.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfa3dec95ca5acd7cfbfac938643bca5',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/239ecafeecb55eabc1f929930fcdfc66.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02709485fd936769d8fe38cf98bc22a3',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/84176bb8ae4bec70eaaef56165137a1e.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34aa29c36f263537e662e3efe0adaec6',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/48f62e1187803954044c59930a696dcf.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6b3ebfc33005ccfd1b4c719e2645107',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/b173cafac104b315d09d2c12881a7a8b.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb9ea9fcc169282889a73c89a95892bc',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/f1979de6f6be70d3d99ab673ff513b8f.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d4e37dfe899816ed211f74083f2fd83',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/10b5d7d40a51d57132e42bda0c5a7ded.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '776c1276d0133bdd074332fae56116a4',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/261c6e0ed06e2230c6f518d315d0eb41.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9c2003c9f34917a2ae9e2e5e5e1e1a6',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/b058b4d44082024e7f52f9064db9d839.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f38112c6e74d54d6fd8b56249eb839d8',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/b89091169fd5a91434594cb7b97a96dc.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '31b75c7c0516e1754fd88ebb0a60bd53',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/2959dfdf03905f489668ee4b53fe31d9.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a31580c3b7936db9a2a2ccc23eb7c02',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/a42ffe1e7dbefd1f76c4e092f32df398.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c33750f38a0ea9216aeef45c80ed852',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/7f64ff30b4a1fcc06490b9c28e4289d9.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0981cc2ea79e46e32df62879a89983b6',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/16464798eea55efb9ed7934c906fa3ed.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a426c89bbbd6f85156ed5a667af00f40',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/12c6481c647817dd36f141b1ddb123a3.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd5451242abcc8e7dd0050370db1e95f',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/7c9083b70e2cc66303a8acd465576e8a.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bdb458c1d5bc333477c656e1e2b45829',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/687b18382bb09f7650a1892948b5de74.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8fee1caae97a64479a8bd2e308ce9da9',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/802bcc7babc705ebe7d7207d57e5b67c.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdc59d79bee47b32bd78dd4514af9d5d',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/064a1b3b2dadf51893d1069d798b6e03.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '097e7995a314c2ee28aeab27e2e25537',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/eb9536cc90f6488f137fa9065476b8ba.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5b872ce9b2a8184c69539839f5d22c5b',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/444b4316cbfb6a0162cb5abefc1f5ef6.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75ddf51357295348ba59f393a288f24d',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/33b7a3710d4d90d2d389f23a9bdac48b.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd7e5db2f5914100a14cff994a2c832da',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/eac6a487c93765ab170f6b53cbcfabae.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea7387ed070937efc09d5e6b61487b13',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/8b67c683789e8d223f05413fff82ceaa.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0abbbc4b92d78ccb686b6b1827d766a',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/b618e5179572b581ba7443f84f8266f9.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6c4253a14e98ae9606f0eaf8f45e9d5',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/4283cd73b45bc2bbaef341cb399c3ef9.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b9973b6a62c206658c414d18b308eba',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/04f06da8cb132a4de7f3899f51e3dbe9.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46d47a07502508409ac2f9b9ec9a1b46',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/9399b1753355d63d1882e99161963722.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f497d345f4dda56441b275657b6a8403',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/74f7e7b88f6178b086948ff19d305a28.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd104f791d960dc763114e45d120cbdc0',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/2fbe10e03231557c2a494932c7192b04.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37c9859cf261ae17145638e596397eba',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/e5ca095a47db35c3f931dcabdb17c8a7.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3e4d19b5c40caf9d0f1fc173a24343d9',
      'native_key' => 'allow_tv_eval',
      'filename' => 'modSystemSetting/20f57f6d53feb376dccbfd2026c8a8bc.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da41964cacbb3e7d552a84a397f58d67',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'modSystemSetting/ab6aecab1c7db51fa5fe642923acd738.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51f0d1a9aca7b5fd452a2c58d7dd667e',
      'native_key' => 'error_log_filename',
      'filename' => 'modSystemSetting/1b1eabd54e864e18d94b7cae5475c634.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7499dae28fd3cfebd264e07792caa60',
      'native_key' => 'error_log_filepath',
      'filename' => 'modSystemSetting/74f203c79748f51fbd864281c3323faa.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '50e1b2d0c31ed824d5c3e059af7bf638',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/2a7576956b6590253576da928a6763ea.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '95b25064d0a49a7ef2eef6741e456424',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/dd175b29e6fcc0bfeb2c4a2cb3bce5ab.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'f2d7c6b73b06afdf64b9b1e7319fec3a',
      'native_key' => 1,
      'filename' => 'modUserGroup/dd0245d29132a47f1af2cef7ff8d0ad6.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '883f3b63c658624faa855e2157960337',
      'native_key' => 1,
      'filename' => 'modDashboard/5b8fb65e5c8f6485d3436313cba18141.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '81b69afd94e9267138e163fbf3554318',
      'native_key' => 1,
      'filename' => 'modMediaSource/398a0e6b2f03c431187025dc0df604b7.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'ac93cbf1f0dfb6964b0cdcdacdfd10a3',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/4aeef007fe0d1e5a9e04524ebd6607d5.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'a9ec11f103231c867f2919bfe4af2412',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/14129e58b54bc921a6047572796fa754.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'efae5f25c6641c34d61be36a38ae8fc5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/fd3e79a660fe84cfd547f8f8566dc05d.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'e0a96fdc69041bf313fa984b7dbc3428',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/ca0914c52485e3677414a5e3621ec0df.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '36a20e50954001273b58999a87132303',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/1f3b88a6edfa94e870f87b8a3dbd7162.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '58f3c92057d34a259b0c00a1c5a7ff89',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/2f8ee066e84e1ddda89de5ef695a8b5c.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '744077713805d97299855b579366bc86',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/18e845bb6e91f7127890456718dbfd93.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '4d2b1897f20cc1bb58ebc2929117396e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/54af585d685068061c5baaf6b6f3fc82.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ccdd8ff007d531f320d3188ffcfca29e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5dd21640469a1793b462d8afb845e2c1.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '8ff19dc118d91bde8778f723482292bb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/708a7d714c94076c490396363b294143.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '207b0fb1c2da46848bd713a8ba3290cf',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/d16e27ab0d912dd18e4494edd34f9283.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'd3bd5b0544e761628ed4c03829f4146a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/545fd7a467faa3ad51f37962ecc0ee7a.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'afcfb81df4071f44e785bac19acbcca8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/4260d4020a7959cb930b92bb8f98b206.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'cc87fcdc820c9176a7eb8ab7bf619089',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8d69f6ae3bbf7f8f4bc7a99077065776.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd063a4e100098b16b2d4bb0e7f52ac20',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/8232140b9aaba2d8a251b5343c751584.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a02980b78a48530801c84c3457d9ecd0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b759fd715ce49f246e2fd06030f1be85.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'ec4e0dc624c4fe234b7e26217fa570e0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/632e9a4177878e4df02a8df751ddd324.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'aabbd13ff9890070ce9d1ba40807c7b0',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/f8d73d8364acf32d4f8bb85d4472500f.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '00a3b414104485470b54ea73f7147e5a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4c40506610e0da23255c67cee5fefae2.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd8431aed3a71e699ccae2708c538b939',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/0551bba3f3e99b654ffc88c1f7c40f3b.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a2f37fb8904c6bc8f3932d165c8733b1',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/89683942492d9ef2e88c0274bfca8791.vehicle',
    ),
    478 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5f7de8ebf1e471a0e691ae4efc4f4287',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/f3e7f20dfee66c27e691aafee7ebc340.vehicle',
    ),
    479 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '7cea15fbf976b548c6b94c9690238f8a',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/9aba5eb38f283e0722d97e0e67ad55b2.vehicle',
    ),
    480 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'af61f949fae29c66291d78d93eea2f61',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/02ccc1e106014392b971a88b06d2d446.vehicle',
    ),
    481 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '58e89eea04579821cabee467a7a4fd9f',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/779d47da6770a3d38efb8219704bd697.vehicle',
    ),
    482 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '661cef34e47b26eae0638afa1ca1173f',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/0d263cc7f98cf5b6a4f1eb686261b389.vehicle',
    ),
    483 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a498a9d3dc9fde4781d5ac0bf687fde1',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/5498491222a82f3c5f4bec21dd21b878.vehicle',
    ),
    484 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '08406047d6b5c6f0bf95552acac9fddd',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/5aa4f0474aa0fc68c39da070016e67c8.vehicle',
    ),
    485 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '524e5dcf0caa677064d660fea97e6ee2',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/f1a9a63b0572343135bf55d45e3c5cbe.vehicle',
    ),
    486 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1a012791943287f36394578490cc7eb9',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/35d8aea827721e9114b93c9f91097a1b.vehicle',
    ),
    487 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd57127ddf9c20f56cd5cd39f894092ca',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/8fc92826ae7d68fe225d8784b1d1ac81.vehicle',
    ),
    488 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ebffa8c3047f0609bf7ccde38fbd85ef',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/fee6c55219942c23addd3da3bbe96fd7.vehicle',
    ),
    489 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '0ae4d7b669b6b1592cb0863d900bc668',
      'native_key' => 'web',
      'filename' => 'modContext/6065ded44761b999b223354c726f3058.vehicle',
    ),
    490 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '29f1baabc4259fa7df257d287e5149b2',
      'native_key' => 'mgr',
      'filename' => 'modContext/b3a6dfa692e52f0aed490bada1eca6ae.vehicle',
    ),
    491 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '8e8ee726a9851fb4984d831f91a35a81',
      'native_key' => '8e8ee726a9851fb4984d831f91a35a81',
      'filename' => 'xPDOFileVehicle/3c36612ba5097803f8f75db674e1f91e.vehicle',
    ),
    492 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4cbdcc3382126e113c90d8e90e391729',
      'native_key' => '4cbdcc3382126e113c90d8e90e391729',
      'filename' => 'xPDOFileVehicle/f324baa0ae587fba277bfe47b98ef502.vehicle',
    ),
    493 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e3fe2ba02a9f04756bdb0b7dc59aea02',
      'native_key' => 'e3fe2ba02a9f04756bdb0b7dc59aea02',
      'filename' => 'xPDOFileVehicle/708f937e96b783c3b078e2be3ef40942.vehicle',
    ),
    494 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '193e57c38c3e6d2321c1b62d23c188a5',
      'native_key' => '193e57c38c3e6d2321c1b62d23c188a5',
      'filename' => 'xPDOFileVehicle/86cd16205bea240a8ca67f8f25c1fb79.vehicle',
    ),
  ),
);